"""Summarise pilot result files: mean ± SD, n, Holm-adjusted two-sided Wilcoxon tests vs a reference, effect sizes,
and figures (TRE box plot, registration bar charts). Every table is generated from the CSV files, never typed.

python analyse.py results/prostate results/liver out_dir
"""
import os, sys, json
import numpy as np, pandas as pd
from scipy.stats import wilcoxon
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

P, L, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(OUT, exist_ok=True)
BLUE, VERM, GREY, INK = "#0072B2", "#D55E00", "#8C96A0", "#1F2328"


def holm(p):
    p = np.asarray(p, float); m = len(p); o = np.argsort(p); adj = np.empty(m); run = 0
    for r, i in enumerate(o):
        run = max(run, (m - r) * p[i]); adj[i] = min(1, run)
    return adj


def summary(df, metrics, ref, key="case_id", decimals=None, higher_better=None):
    decimals = decimals or {}; rows = []
    meths = list(dict.fromkeys(df["method"]))
    for mth in meths:
        g = df[df.method == mth]; r = {"method": mth, "n": g[key].nunique()}
        for m in metrics:
            d = decimals.get(m, 2); r[m] = f"{g[m].mean():.{d}f} ± {g[m].std(ddof=1):.{d}f}"
        rows.append(r)
    out = pd.DataFrame(rows)
    for m in metrics:
        piv = df.pivot_table(index=key, columns="method", values=m)
        others = [x for x in meths if x != ref]; raw, eff = [], []
        for b in others:
            pr = piv[[ref, b]].dropna()
            if len(pr) < 2 or np.allclose(pr[ref], pr[b]):
                raw.append(1.0); eff.append(np.nan); continue
            raw.append(wilcoxon(pr[ref], pr[b], alternative="two-sided").pvalue)
            eff.append(float((pr[ref] - pr[b]).median()))
        adj = dict(zip(others, holm(raw))); med = dict(zip(others, eff))
        out[f"p_holm_{m}"] = ["–" if x == ref else f"{adj[x]:.3g}" for x in out.method]
        out[f"median_diff_{m}"] = ["–" if x == ref else f"{med[x]:+.3f}" for x in out.method]
    return out


report = {}
# ------------------------------------------------------------------ prostate (paired mu-RegPro)
pc = pd.read_csv(os.path.join(P, "per_case_paired.csv"))
s = summary(pc, ["dice", "hd95_mm", "asd_mm", "tre_mm", "nonpos_jacobian_pct"], "Proposed",
            decimals={"hd95_mm": 1, "asd_mm": 2, "tre_mm": 2, "nonpos_jacobian_pct": 2})
s.to_csv(os.path.join(OUT, "table_paired_registration.csv"), index=False); report["paired"] = s
allseeds = pd.read_csv(os.path.join(P, "per_case_paired_all_seeds.csv"))
seed_sd = allseeds.groupby(["method", "seed"])[["dice", "tre_mm"]].mean().groupby("method").std(ddof=1)
seed_sd.to_csv(os.path.join(OUT, "seed_variability_paired.csv"))
lm = pd.read_csv(os.path.join(P, "per_landmark_tre.csv"))
order = list(dict.fromkeys(pc["method"]))
fig, ax = plt.subplots(figsize=(6.4, 2.9))
data = [lm.loc[lm.method == m, "tre_mm"].dropna().values for m in order]
bp = ax.boxplot(data, widths=0.55, patch_artist=True, medianprops={"color": INK, "lw": 1.2}, flierprops={"markersize": 2.5})
for patch, m in zip(bp["boxes"], order):
    patch.set_facecolor(VERM if m == "Proposed" else (GREY if m == "Before registration" else BLUE)); patch.set_alpha(0.85)
ax.set_xticks(range(1, len(order) + 1)); ax.set_xticklabels([m.replace(" (", "\n(").replace("w/o ", "w/o\n") for m in order], fontsize=7)
ax.set_ylabel("Landmark TRE (mm), lower is better", fontsize=8); ax.tick_params(axis="y", labelsize=7)
for sp in ["top", "right"]: ax.spines[sp].set_visible(False)
ax.yaxis.grid(True, color="#E3E6EA", lw=0.6); ax.set_axisbelow(True)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig07_tre_muregpro.png"), dpi=600, bbox_inches="tight", facecolor="white"); plt.close(fig)
report["n_landmarks"] = int(lm[lm.method == "Proposed"].shape[0]); report["n_patients"] = int(pc.case_id.nunique())
tr = pd.read_csv(os.path.join(P, "translation_realism.csv")); tr.to_csv(os.path.join(OUT, "table_prostate_translation_realism.csv"), index=False)
if os.path.exists(os.path.join(P, "lambda_selection.csv")):
    pd.read_csv(os.path.join(P, "lambda_selection.csv")).to_csv(os.path.join(OUT, "lambda_selection.csv"), index=False)

# ------------------------------------------------------------------ liver
if os.path.exists(os.path.join(L, "per_case_translation.csv")):
    t = pd.read_csv(os.path.join(L, "per_case_translation.csv"))
    # statistics at subject level (slices within a subject are not independent) and at slice level
    ts = summary(t, ["anat_dice", "anat_hd95_mm"], "proposed", decimals={"anat_hd95_mm": 1})
    ts.to_csv(os.path.join(OUT, "table_liver_anatomical_consistency_slices.csv"), index=False)
    tsub = t.groupby(["subject", "method"], as_index=False)[["anat_dice", "anat_hd95_mm"]].mean().rename(columns={"subject": "case_id"})
    summary(tsub, ["anat_dice", "anat_hd95_mm"], "proposed", decimals={"anat_hd95_mm": 1}).to_csv(
        os.path.join(OUT, "table_liver_anatomical_consistency_subjects.csv"), index=False)
    pd.read_csv(os.path.join(L, "translation_realism.csv")).to_csv(os.path.join(OUT, "table_liver_translation_realism.csv"), index=False)
    sg = pd.read_csv(os.path.join(L, "per_case_segmentation.csv"))
    ss = summary(sg, ["dice"], "MRI + proposed synthetic US")
    ss["n_train"] = [int(sg[sg.method == m]["n_train"].iloc[0]) for m in ss.method]
    ss.to_csv(os.path.join(OUT, "table_liver_downstream_segmentation.csv"), index=False)
    report["liver"] = (ts, ss)

with open(os.path.join(OUT, "summary.txt"), "w") as f:
    for k, v in report.items():
        f.write(f"== {k}\n{v if not isinstance(v, tuple) else chr(10).join(x.to_string(index=False) for x in v)}\n\n")
print(open(os.path.join(OUT, "summary.txt")).read())
