"""Registration losses (local NCC, MIND-SSC, smoothness, anatomy weighting) and evaluation metrics."""
import numpy as np
import torch
import torch.nn.functional as F
from scipy import ndimage


# ----------------------------------------------------------------------------- losses
def _box(x, win):
    dim = x.dim() - 2
    k = torch.ones((1, 1) + (win,) * dim, device=x.device) / win ** dim
    conv = F.conv3d if dim == 3 else F.conv2d
    return conv(x, k, padding=win // 2)


def local_ncc_map(a, b, win=9, eps=1e-5):
    ma, mb = _box(a, win), _box(b, win)
    va = _box(a * a, win) - ma * ma
    vb = _box(b * b, win) - mb * mb
    cov = _box(a * b, win) - ma * mb
    return cov * cov / (va * vb + eps)               # squared local correlation in [0, 1]


def weighted_dissimilarity(warped, fixed, w=None, win=9):
    """1 - weighted local NCC^2 (the dissimilarity D of Eq. 14)."""
    cc = local_ncc_map(warped, fixed, win)
    if w is None:
        return 1 - cc.mean()
    return 1 - (w * cc).sum() / w.sum().clamp_min(1e-6)


def anatomy_weight(mri, kappa=10.0, tau=0.5):
    """w(x) = sigmoid(kappa (tau - I_MRI(x))), MRI in [0, 1] (Eq. 11)."""
    return torch.sigmoid(kappa * (tau - mri))


def mind_ssc(x, radius=1, dilation=2):
    """MIND-SSC-style self-similarity descriptor (2D/3D) used for the cross-modal VoxelMorph baseline."""
    dim = x.dim() - 2
    shifts = []
    for ax in range(dim):
        for s in (-dilation, dilation):
            shifts.append((ax, s))
    pads = [radius] * (2 * dim)
    feats = []
    xs = [torch.roll(x, s, dims=2 + ax) for ax, s in shifts]
    for i in range(len(xs)):
        for j in range(i + 1, len(xs)):
            d = (xs[i] - xs[j]) ** 2
            feats.append(_box(d, 2 * radius + 1))
    f = torch.cat(feats, 1)
    v = f.mean(1, keepdim=True).clamp_min(1e-6)
    f = torch.exp(-f / v)
    return f / f.amax(1, keepdim=True).clamp_min(1e-6)


def mind_loss(a, b):
    return torch.mean((mind_ssc(a) - mind_ssc(b)) ** 2)


def smoothness(flow):
    dim = flow.shape[1]; l = 0
    for ax in range(dim):
        d = torch.diff(flow, dim=2 + ax)
        l = l + (d ** 2).mean()
    return l / dim


# ----------------------------------------------------------------------------- metrics
def dice(a, b):
    a, b = a.astype(bool), b.astype(bool)
    s = a.sum() + b.sum()
    return float(2 * (a & b).sum() / s) if s > 0 else np.nan


def _surface(m):
    return m ^ ndimage.binary_erosion(m)


def surface_distances(a, b, spacing):
    a, b = a.astype(bool), b.astype(bool)
    if a.sum() == 0 or b.sum() == 0:
        return None
    sa, sb = _surface(a), _surface(b)
    da = ndimage.distance_transform_edt(~sb, sampling=spacing)[sa]
    db = ndimage.distance_transform_edt(~sa, sampling=spacing)[sb]
    return np.concatenate([da, db])


def hd95(a, b, spacing):
    d = surface_distances(a, b, spacing)
    return float(np.percentile(d, 95)) if d is not None else np.nan


def asd(a, b, spacing):
    d = surface_distances(a, b, spacing)
    return float(d.mean()) if d is not None else np.nan


def centroid(m, spacing):
    idx = np.argwhere(m > 0.5)
    return None if len(idx) == 0 else idx.mean(0) * np.asarray(spacing)


def tre(mask_a, mask_b, spacing):
    ca, cb = centroid(mask_a, spacing), centroid(mask_b, spacing)
    return np.nan if ca is None or cb is None else float(np.linalg.norm(ca - cb))


def folding_percent(flow):
    """% of voxels with det(J) <= 0 for x -> x + u(x); flow (D, *S) numpy in voxels."""
    dim = flow.shape[0]
    grads = [np.gradient(flow[i], axis=tuple(range(dim))) for i in range(dim)]
    J = np.zeros(flow.shape[1:] + (dim, dim))
    for i in range(dim):
        for j in range(dim):
            J[..., i, j] = grads[i][j] + (1.0 if i == j else 0.0)
    return float((np.linalg.det(J) <= 0).mean() * 100)


# ----------------------------------------------------------------------------- FID / KID (Inception-v3, pytorch-fid weights)
_INC = None


def inception_features(imgs, bs=64):
    """imgs: (N,S,S) in [0,1] -> (N,2048) pool3 features."""
    global _INC
    from pytorch_fid.inception import InceptionV3
    if _INC is None:
        _INC = InceptionV3([InceptionV3.BLOCK_INDEX_BY_DIM[2048]]).eval()
    feats = []
    with torch.no_grad():
        for i in range(0, len(imgs), bs):
            x = torch.from_numpy(np.asarray(imgs[i:i + bs], np.float32))[:, None].repeat(1, 3, 1, 1)
            x = F.interpolate(x, size=(299, 299), mode="bilinear", align_corners=False)
            feats.append(_INC(x)[0].squeeze(-1).squeeze(-1).numpy())
    return np.concatenate(feats).astype(np.float64)


def fid_from_feats(f1, f2):
    from scipy import linalg
    m1, m2 = f1.mean(0), f2.mean(0)
    s1, s2 = np.cov(f1, rowvar=False), np.cov(f2, rowvar=False)
    covmean = linalg.sqrtm(s1.dot(s2))
    if np.iscomplexobj(covmean):
        covmean = covmean.real
    return float(((m1 - m2) ** 2).sum() + np.trace(s1 + s2 - 2 * covmean))


def kid_from_feats(f1, f2, n_subsets=50, subset=100, seed=0):
    """Unbiased polynomial-kernel MMD^2 (Binkowski et al.), mean over random subsets."""
    rng = np.random.default_rng(seed); d = f1.shape[1]; m = min(subset, len(f1), len(f2)); vals = []
    for _ in range(n_subsets):
        x = f1[rng.choice(len(f1), m, replace=False)]; y = f2[rng.choice(len(f2), m, replace=False)]
        kxx = (x @ x.T / d + 1) ** 3; kyy = (y @ y.T / d + 1) ** 3; kxy = (x @ y.T / d + 1) ** 3
        vals.append((kxx.sum() - np.trace(kxx)) / (m * (m - 1)) + (kyy.sum() - np.trace(kyy)) / (m * (m - 1)) - 2 * kxy.mean())
    return float(np.mean(vals)), float(np.std(vals))
