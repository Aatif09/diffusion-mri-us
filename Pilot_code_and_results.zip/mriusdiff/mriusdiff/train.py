"""Training routines for translators, segmentation U-Net and registration networks."""
import os, time
import numpy as np
import torch
import torch.nn.functional as F
from .models import Translator, PlainUNet, PatchD, RegUNet, warp, integrate
from .diffusion import Diffusion
from .losses_metrics import weighted_dissimilarity, anatomy_weight, mind_loss, mind_ssc, smoothness


DEV = torch.device(os.environ.get("MRIUS_DEVICE", "cuda" if torch.cuda.is_available() else "cpu"))


def seed_all(s):
    torch.manual_seed(s); np.random.seed(s)


def _batches(n, bs, rng):
    while True:
        idx = rng.permutation(n)
        for i in range(0, n - bs + 1, bs):
            yield idx[i:i + bs]


def t4(a):  # (N,S,S) numpy -> (N,1,S,S) tensor on DEV
    return torch.from_numpy(np.asarray(a, np.float32))[:, None].to(DEV)


# ----------------------------------------------------------------------------- translators
def train_translator(mri, us, cfg, seed, kind="diffusion", encoder="vit", log=print, state=None):
    """mri, us: (N,S,S) arrays in [0,1]; row i of mri is paired with row i of us (paired or random tuples)."""
    seed_all(seed); rng = np.random.default_rng(seed)
    S = mri.shape[-1]; tc = cfg["translator"]
    X, Y = t4(mri), t4(us) * 2 - 1
    if kind == "cyclegan":
        return train_cyclegan(mri, us, cfg, seed, log)
    if kind == "cnn":
        net = PlainUNet(tuple(tc["ch"]))
    else:
        net = Translator(S, encoder, "diffusion" if kind == "diffusion" else "direct", tc["dim"], tc["depth"], tc["patch"], tuple(tc["ch"]))
    net = net.to(DEV)
    opt = torch.optim.AdamW(net.parameters(), lr=tc["lr"], betas=(0.9, 0.999), weight_decay=0.01)
    steps = tc["steps"]; warm = max(1, int(0.05 * steps))
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: min(1, (s + 1) / warm) * 0.5 * (1 + np.cos(np.pi * min(s, steps) / steps)))
    diff = Diffusion(tc["T"])
    if kind == "pix2pix":
        D = PatchD(2).to(DEV); optD = torch.optim.Adam(D.parameters(), lr=2e-4, betas=(0.5, 0.999))
    it = _batches(len(X), tc["batch"], rng); t0 = time.time()
    if state is not None:
        net.load_state_dict(state); steps = 0; log(f"  [{kind}/{encoder}] loaded trained weights")
    for step in range(steps):
        b = next(it); x, y = X[b], Y[b]
        if kind == "diffusion":
            loss = diff.loss(net, y, x)
        elif kind == "cnn":
            loss = F.l1_loss(net(x) * 2 - 1, y)
        else:  # pix2pix: direct generator conditioned on MRI tokens + PatchGAN
            fake = torch.tanh(net(x, None, x))
            dl = F.mse_loss(D(torch.cat([x, y], 1)), torch.ones_like(D(torch.cat([x, y], 1)))) + \
                F.mse_loss(D(torch.cat([x, fake.detach()], 1)), torch.zeros_like(D(torch.cat([x, y], 1))))
            optD.zero_grad(); dl.backward(); optD.step()
            pred = D(torch.cat([x, fake], 1))
            loss = F.mse_loss(pred, torch.ones_like(pred)) + tc["l1_weight"] * F.l1_loss(fake, y)
        opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt.step(); sched.step()
        if step % max(1, steps // 10) == 0:
            log(f"  [{kind}/{encoder}] step {step}/{steps} loss {loss.item():.4f} ({time.time() - t0:.0f}s)")
    net.eval()

    @torch.no_grad()
    def generate(m, seed_g=0, bs=128, volume=False):
        outs = []
        g = torch.Generator(device=DEV).manual_seed(seed_g)
        bs = len(m) if volume else bs          # a whole volume is sampled in one batch with shared noise
        for i in range(0, len(m), bs):
            xb = t4(m[i:i + bs])
            if kind == "diffusion":
                o = diff.ddim(net, xb, tc["ddim_steps"], generator=g, shared_noise=volume)
            elif kind == "cnn":
                o = net(xb) * 2 - 1
            else:
                o = torch.tanh(net(xb, None, xb))
            outs.append(((o + 1) / 2)[:, 0].cpu().numpy())
        return np.concatenate(outs)
    generate.net = net
    return generate


def train_cyclegan(mri, us, cfg, seed, log=print):
    """Unpaired CycleGAN (LSGAN + cycle L1) with U-Net generators."""
    seed_all(seed); rng = np.random.default_rng(seed); tc = cfg["translator"]
    A, B = t4(mri) * 2 - 1, t4(us) * 2 - 1
    G, Fn = PlainUNet(tuple(tc["ch"])).to(DEV), PlainUNet(tuple(tc["ch"])).to(DEV)
    DA, DB = PatchD(1).to(DEV), PatchD(1).to(DEV)
    og = torch.optim.Adam(list(G.parameters()) + list(Fn.parameters()), lr=2e-4, betas=(0.5, 0.999))
    od = torch.optim.Adam(list(DA.parameters()) + list(DB.parameters()), lr=2e-4, betas=(0.5, 0.999))
    g = lambda net, x: net((x + 1) / 2) * 2 - 1
    ia, ib = _batches(len(A), tc["batch"], rng), _batches(len(B), tc["batch"], rng)
    for step in range(tc["steps"]):
        a, b = A[next(ia)], B[next(ib)]
        fb, fa = g(G, a), g(Fn, b)
        p1, p2 = DB(fb), DA(fa)
        lg = F.mse_loss(p1, torch.ones_like(p1)) + F.mse_loss(p2, torch.ones_like(p2)) + \
            10 * (F.l1_loss(g(Fn, fb), a) + F.l1_loss(g(G, fa), b))
        og.zero_grad(); lg.backward(); og.step()
        ld = sum(F.mse_loss(D(r), torch.ones_like(D(r))) + F.mse_loss(D(f.detach()), torch.zeros_like(D(r)))
                 for D, r, f in ((DB, b, fb), (DA, a, fa)))
        od.zero_grad(); ld.backward(); od.step()
        if step % max(1, tc["steps"] // 10) == 0:
            log(f"  [cyclegan] step {step}/{tc['steps']} G {lg.item():.3f} D {ld.item():.3f}")
    G.eval()

    @torch.no_grad()
    def generate(m, seed_g=0, bs=128):
        return np.concatenate([G(t4(m[i:i + bs]))[:, 0].cpu().numpy() for i in range(0, len(m), bs)])
    generate.net = G
    return generate


# ----------------------------------------------------------------------------- segmentation U-Net
def train_segmenter(imgs, masks, cfg, seed, log=print):
    seed_all(seed); rng = np.random.default_rng(seed); sc = cfg["segmenter"]
    X, Y = t4(imgs), t4(masks.astype(np.float32))
    net = PlainUNet(tuple(sc["ch"])).to(DEV)
    opt = torch.optim.AdamW(net.parameters(), lr=sc["lr"], weight_decay=0.01)
    it = _batches(len(X), min(sc["batch"], len(X)), rng)
    for step in range(sc["steps"]):
        b = next(it); x, y = X[b], Y[b]
        if rng.random() < 0.5:
            x, y = x.flip(-1), y.flip(-1)
        p = net(x)
        loss = F.binary_cross_entropy(p, y) + 1 - (2 * (p * y).sum() + 1) / (p.sum() + y.sum() + 1)
        opt.zero_grad(); loss.backward(); opt.step()
        if step % max(1, sc["steps"] // 5) == 0:
            log(f"  [segmenter] step {step}/{sc['steps']} loss {loss.item():.4f}")
    net.eval()

    @torch.no_grad()
    def predict(im, bs=256):
        return np.concatenate([net(t4(im[i:i + bs]))[:, 0].cpu().numpy() > 0.5 for i in range(0, len(im), bs)])
    return predict


# ----------------------------------------------------------------------------- registration (3D or 2D)
def train_registration(moving, fixed, mri, cfg, seed, loss_kind="ncc", anatomy=True, log=print, lambda_smooth=None):
    """moving: real US; fixed: calibrated US (loss_kind='ncc') or MRI (loss_kind='mind'); mri gives w(x).
    Arrays shaped (N,*S) in [0,1]. Unsupervised: no labels are used."""
    seed_all(seed); rng = np.random.default_rng(seed); rc = cfg["registration"]
    dim = moving.ndim - 1
    M, Fx, R = t4(moving), t4(fixed), t4(mri)
    net = RegUNet(dim, tuple(rc["ch"])).to(DEV)
    opt = torch.optim.Adam(net.parameters(), lr=rc["lr"])
    it = _batches(len(M), rc["batch"], rng); t0 = time.time()
    for step in range(rc["steps"]):
        b = next(it); m, f, r = M[b], Fx[b], R[b]
        flow = net(m, f)
        if rc.get("diffeo", True):
            flow = integrate(flow, rc.get("int_steps", 7))
        wm = warp(m, flow)
        fov = (warp((m > 0.01).float(), flow) > 0.5).float()          # warped ultrasound field of view
        if loss_kind == "mind":
            sim = (fov * (mind_ssc(wm) - mind_ssc(f)) ** 2).mean(1, keepdim=True).sum() / fov.sum().clamp_min(1)
        else:
            w = anatomy_weight(r, rc["kappa"], rc["tau"]) * fov if anatomy else fov
            sim = weighted_dissimilarity(wm, f, w, rc["ncc_win"])
        loss = sim + (rc["lambda_smooth"] if lambda_smooth is None else lambda_smooth) * smoothness(flow)
        opt.zero_grad(); loss.backward(); opt.step()
        if step % max(1, rc["steps"] // 5) == 0:
            log(f"  [reg/{loss_kind}/aw={anatomy}] step {step}/{rc['steps']} loss {loss.item():.4f} ({time.time() - t0:.0f}s)")
    net.eval()

    @torch.no_grad()
    def register(mv, fx):
        v = net(t4(mv[None])[0:1], t4(fx[None])[0:1])
        if rc.get("diffeo", True):
            v = integrate(v, rc.get("int_steps", 7))
        return v[0].cpu().numpy()     # displacement (D,*S) in voxels
    register.net = net
    return register
