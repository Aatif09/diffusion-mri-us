"""Cosine-schedule DDPM training objective and deterministic DDIM sampling (Eqs. 6-8)."""
import math
import torch


def cosine_alpha_bar(T, s=0.008):
    t = torch.arange(T + 1, dtype=torch.float64) / T
    f = torch.cos((t + s) / (1 + s) * math.pi / 2) ** 2
    ab = (f / f[0]).clamp(1e-5, 1.0)
    return ab[1:].float()                        # alpha_bar_t for t = 1..T  (index t-1)


class Diffusion:
    def __init__(self, T=1000):
        self.T = T
        self.ab = cosine_alpha_bar(T)

    def loss(self, model, x0, mri):
        """x0 in [-1, 1]. Returns ||eps - eps_hat||^2 (Eq. 13)."""
        b = x0.shape[0]
        t = torch.randint(1, self.T + 1, (b,), device=x0.device)
        ab = self.ab.to(x0.device)[t - 1].view(-1, 1, 1, 1)
        eps = torch.randn_like(x0)
        xt = ab.sqrt() * x0 + (1 - ab).sqrt() * eps
        return torch.mean((eps - model(xt, t, mri)) ** 2)

    @torch.no_grad()
    def ddim(self, model, mri, steps=50, generator=None, shared_noise=False):
        b = mri.shape[0]
        if shared_noise:   # one noise image for every slice of a volume -> slice-consistent sampling
            x = torch.randn((1,) + tuple(mri.shape[1:]), generator=generator, device=mri.device).expand_as(mri).clone()
        else:
            x = torch.randn(mri.shape, generator=generator, device=mri.device)
        ts = torch.linspace(self.T, 1, steps).round().long().tolist()
        ab = self.ab.to(mri.device)
        ctx = model.enc(mri)
        for i, t in enumerate(ts):
            a_t = ab[t - 1]
            a_prev = ab[ts[i + 1] - 1] if i + 1 < len(ts) else torch.tensor(1.0, device=mri.device)
            eps = model.unet(x, torch.full((b,), t, device=mri.device), ctx)
            x0 = ((x - (1 - a_t).sqrt() * eps) / a_t.sqrt()).clamp(-1, 1)
            x = a_prev.sqrt() * x0 + (1 - a_prev).sqrt() * eps
        return x.clamp(-1, 1)
