"""Networks: ViT / CNN condition encoders, cross-attention diffusion U-Net, GAN baselines, registration U-Nets."""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


# ----------------------------------------------------------------------------- condition encoders (C1)
class TinyViT(nn.Module):
    """ViT encoder that returns patch tokens (B, N, dim)."""
    def __init__(self, img=64, patch=8, dim=128, depth=4, heads=4, in_ch=1):
        super().__init__()
        self.proj = nn.Conv2d(in_ch, dim, patch, stride=patch)
        n = (img // patch) ** 2
        self.pos = nn.Parameter(torch.zeros(1, n, dim)); nn.init.trunc_normal_(self.pos, std=0.02)
        layer = nn.TransformerEncoderLayer(dim, heads, dim * 4, dropout=0.0, batch_first=True, norm_first=True,
                                           activation="gelu")
        self.enc = nn.TransformerEncoder(layer, depth, enable_nested_tensor=False)
        self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        t = self.proj(x).flatten(2).transpose(1, 2) + self.pos
        return self.norm(self.enc(t))


class CNNEncoder(nn.Module):
    """Ablation of C1: convolutional encoder with the same token output shape (local receptive field)."""
    def __init__(self, img=64, patch=8, dim=128, in_ch=1):
        super().__init__()
        layers, c, s = [], in_ch, 1
        ch = [32, 64, dim]
        while s < patch:
            nc = ch[min(len(ch) - 1, int(math.log2(s)))]
            layers += [nn.Conv2d(c, nc, 3, stride=2, padding=1), nn.GroupNorm(8, nc), nn.SiLU()]
            c, s = nc, s * 2
        layers += [nn.Conv2d(c, dim, 3, padding=1)]
        self.net = nn.Sequential(*layers)
        self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        return self.norm(self.net(x).flatten(2).transpose(1, 2))


# ----------------------------------------------------------------------------- diffusion U-Net with cross-attention
def timestep_embedding(t, dim):
    half = dim // 2
    freqs = torch.exp(-math.log(10000) * torch.arange(half, device=t.device) / half)
    a = t.float()[:, None] * freqs[None]
    return torch.cat([a.sin(), a.cos()], 1)


class ResBlock(nn.Module):
    def __init__(self, cin, cout, tdim):
        super().__init__()
        self.n1, self.c1 = nn.GroupNorm(8, cin), nn.Conv2d(cin, cout, 3, padding=1)
        self.t = nn.Linear(tdim, cout)
        self.n2, self.c2 = nn.GroupNorm(8, cout), nn.Conv2d(cout, cout, 3, padding=1)
        self.skip = nn.Conv2d(cin, cout, 1) if cin != cout else nn.Identity()

    def forward(self, x, temb):
        h = self.c1(F.silu(self.n1(x))) + self.t(temb)[:, :, None, None]
        h = self.c2(F.silu(self.n2(h)))
        return h + self.skip(x)


class CrossAttn(nn.Module):
    def __init__(self, ch, cdim, heads=4):
        super().__init__()
        self.norm = nn.GroupNorm(8, ch)
        self.attn = nn.MultiheadAttention(ch, heads, kdim=cdim, vdim=cdim, batch_first=True)

    def forward(self, x, ctx):
        if ctx is None:
            return x
        b, c, h, w = x.shape
        q = self.norm(x).flatten(2).transpose(1, 2)
        o, _ = self.attn(q, ctx, ctx, need_weights=False)
        return x + o.transpose(1, 2).reshape(b, c, h, w)


class CondUNet(nn.Module):
    """ε-prediction U-Net, conditioned on encoder tokens through cross-attention at every scale."""
    def __init__(self, ch=(32, 64, 128), cdim=128, in_ch=1, out_ch=1, time=True):
        super().__init__()
        self.time = time
        td = ch[0] * 4
        self.tmlp = nn.Sequential(nn.Linear(ch[0], td), nn.SiLU(), nn.Linear(td, td))
        self.inc = nn.Conv2d(in_ch, ch[0], 3, padding=1)
        self.down, self.dattn, self.pool = nn.ModuleList(), nn.ModuleList(), nn.ModuleList()
        c = ch[0]
        for i, co in enumerate(ch):
            self.down.append(ResBlock(c, co, td)); self.dattn.append(CrossAttn(co, cdim)); c = co
            self.pool.append(nn.Conv2d(co, co, 3, stride=2, padding=1) if i < len(ch) - 1 else nn.Identity())
        self.mid = ResBlock(c, c, td); self.mattn = CrossAttn(c, cdim)
        self.up, self.uattn, self.ups = nn.ModuleList(), nn.ModuleList(), nn.ModuleList()
        for i, co in reversed(list(enumerate(ch))):
            self.up.append(ResBlock(c + co, co, td)); self.uattn.append(CrossAttn(co, cdim)); c = co
            self.ups.append(nn.Upsample(scale_factor=2, mode="nearest") if i > 0 else nn.Identity())
        self.out = nn.Sequential(nn.GroupNorm(8, c), nn.SiLU(), nn.Conv2d(c, out_ch, 3, padding=1))
        self.ch0 = ch[0]

    def forward(self, x, t, ctx):
        if t is None:
            t = torch.zeros(x.shape[0], device=x.device)
        temb = self.tmlp(timestep_embedding(t, self.ch0))
        h = self.inc(x); skips = []
        for blk, at, pl in zip(self.down, self.dattn, self.pool):
            h = at(blk(h, temb), ctx); skips.append(h); h = pl(h)
        h = self.mattn(self.mid(h, temb), ctx)
        for blk, at, up in zip(self.up, self.uattn, self.ups):
            h = at(blk(torch.cat([h, skips.pop()], 1), temb), ctx); h = up(h)
        return self.out(h)


class Translator(nn.Module):
    """Condition encoder + U-Net. kind='diffusion' predicts ε; kind in {'pix2pix','cnn'} maps MRI→US directly."""
    def __init__(self, img=64, encoder="vit", kind="diffusion", dim=128, depth=4, patch=8, ch=(32, 64, 128)):
        super().__init__()
        self.kind = kind
        self.enc = TinyViT(img, patch, dim, depth) if encoder == "vit" else CNNEncoder(img, patch, dim)
        in_ch = 1 if kind == "diffusion" else 1
        self.unet = CondUNet(ch, dim, in_ch=in_ch)

    def forward(self, x, t, mri):
        return self.unet(x, t, self.enc(mri))


class PlainUNet(nn.Module):
    """Unconditioned image-to-image U-Net (CNN encoder–decoder baseline; GAN generators)."""
    def __init__(self, ch=(32, 64, 128), in_ch=1, out_ch=1):
        super().__init__()
        self.u = CondUNet(ch, cdim=8, in_ch=in_ch, out_ch=out_ch)

    def forward(self, x):
        return torch.sigmoid(self.u(x, None, None))


class PatchD(nn.Module):
    def __init__(self, in_ch=2, ch=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, ch, 4, 2, 1), nn.LeakyReLU(0.2),
            nn.Conv2d(ch, ch * 2, 4, 2, 1), nn.GroupNorm(8, ch * 2), nn.LeakyReLU(0.2),
            nn.Conv2d(ch * 2, ch * 4, 4, 1, 1), nn.GroupNorm(8, ch * 4), nn.LeakyReLU(0.2),
            nn.Conv2d(ch * 4, 1, 4, 1, 1))

    def forward(self, x):
        return self.net(x)


# ----------------------------------------------------------------------------- registration (VoxelMorph-style)
class RegUNet(nn.Module):
    def __init__(self, dim=3, ch=(16, 32, 32, 32), in_ch=2):
        super().__init__()
        Conv = nn.Conv3d if dim == 3 else nn.Conv2d
        self.dim = dim
        self.enc = nn.ModuleList(); c = in_ch
        for co in ch:
            self.enc.append(nn.Sequential(Conv(c, co, 3, stride=2, padding=1), nn.LeakyReLU(0.2))); c = co
        self.dec = nn.ModuleList()
        for co, sk in zip(reversed(ch[:-1]), reversed(ch[:-1])):
            self.dec.append(nn.Sequential(Conv(c + sk, co, 3, padding=1), nn.LeakyReLU(0.2))); c = co
        self.last = nn.Sequential(Conv(c + in_ch, 16, 3, padding=1), nn.LeakyReLU(0.2))
        self.flow = Conv(16, dim, 3, padding=1)
        nn.init.normal_(self.flow.weight, 0, 1e-5); nn.init.zeros_(self.flow.bias)

    def forward(self, moving, fixed):
        x = torch.cat([moving, fixed], 1); skips = [x]; h = x
        for e in self.enc:
            h = e(h); skips.append(h)
        skips.pop()
        mode = "trilinear" if self.dim == 3 else "bilinear"
        for d in self.dec:
            s = skips.pop(); h = F.interpolate(h, size=s.shape[2:], mode=mode, align_corners=False)
            h = d(torch.cat([h, s], 1))
        s = skips.pop(); h = F.interpolate(h, size=s.shape[2:], mode=mode, align_corners=False)
        return self.flow(self.last(torch.cat([h, s], 1)))   # displacement in voxels


def warp(img, flow, mode="bilinear"):
    """Warp img (B,C,*S) with displacement flow (B,D,*S) given in voxels (channel order = spatial axes)."""
    dim = flow.shape[1]
    size = flow.shape[2:]
    grids = torch.meshgrid([torch.arange(s, device=flow.device, dtype=flow.dtype) for s in size], indexing="ij")
    grid = torch.stack(grids, 0)[None] + flow
    for i, s in enumerate(size):
        grid[:, i] = 2 * grid[:, i] / (s - 1) - 1
    grid = grid.permute(0, *range(2, 2 + dim), 1).flip(-1)   # grid_sample expects (x, y[, z]) order
    return F.grid_sample(img, grid, mode=mode, padding_mode="border", align_corners=True)


def integrate(v, steps=7):
    """Scaling and squaring of a stationary velocity field -> diffeomorphic displacement (Dalca et al., 2019)."""
    u = v / (2 ** steps)
    for _ in range(steps):
        u = u + warp(u, u)
    return u
