"""Dataset loaders (CHAOS MR, AUL, mu-RegPro) and a clearly labelled synthetic fixture for plumbing tests."""
import glob, json, os, re
import numpy as np
from skimage.transform import resize
from skimage.draw import polygon as skpolygon


def norm01(x, lo=1, hi=99):
    a, b = np.percentile(x, [lo, hi])
    return np.clip((x - a) / (b - a + 1e-8), 0, 1).astype(np.float32)


def rs(img, size, order=1):
    return resize(img, (size, size), order=order, preserve_range=True, anti_aliasing=(order > 0)).astype(np.float32)


# ----------------------------------------------------------------------------- CHAOS MR (T2-SPIR)
CHAOS_LIVER = (55, 70)    # liver label intensity range in the CHAOS MR ground-truth PNGs


def load_chaos_mr(root, size=64, seqs=("T2SPIR", "T1DUAL/InPhase"), min_liver_px=50):
    """CHAOS MR training subjects. Returns dicts {subject, seq, slice, mri (S,S) [0,1], liver (S,S) bool} for
    slices that contain liver. Ground-truth PNGs are matched to DICOMs by file stem; liver = label 63 (55-70)."""
    import pydicom
    from PIL import Image
    out = []
    for subj_dir in sorted(glob.glob(os.path.join(root, "**", "MR", "*"), recursive=True)):
        subj = os.path.basename(subj_dir)
        for seq in seqs:
            dcm_dir = os.path.join(subj_dir, seq.split("/")[0], "DICOM_anon", *seq.split("/")[1:])
            gt_dir = os.path.join(subj_dir, seq.split("/")[0], "Ground")
            dcms = sorted(glob.glob(os.path.join(dcm_dir, "*.dcm")))
            pairs = [(d, os.path.join(gt_dir, os.path.splitext(os.path.basename(d))[0] + ".png")) for d in dcms]
            pairs = [(d, g) for d, g in pairs if os.path.exists(g)]
            if len(pairs) < 5:
                continue
            try:
                ds = [pydicom.dcmread(d) for d, _ in pairs]
            except Exception:
                continue
            order = np.argsort([float(x.InstanceNumber) for x in ds])
            vol = norm01(np.stack([ds[i].pixel_array.astype(np.float32) for i in order]))
            for k, i in enumerate(order):
                g = np.array(Image.open(pairs[i][1]))
                liver = (g >= CHAOS_LIVER[0]) & (g <= CHAOS_LIVER[1])
                if liver.sum() < min_liver_px:
                    continue
                out.append(dict(subject=subj, seq=seq.split("/")[0], slice=k, mri=rs(vol[k], size),
                                liver=rs(liver.astype(np.float32), size, 0) > 0.5))
    return out


# ----------------------------------------------------------------------------- AUL liver ultrasound
def _aul_mask_from_json(js, shape):
    """AUL outlines are stored as a list of [x, y] vertices (one polygon) or a list of such polygons."""
    m = np.zeros(shape, bool)
    polys = [js] if (len(js) and isinstance(js[0], (list, tuple)) and len(js[0]) == 2 and
                     not isinstance(js[0][0], (list, tuple))) else js
    for pts in polys:
        pts = np.asarray(pts, float)
        if pts.ndim != 2 or len(pts) < 3:
            continue
        rr, cc = skpolygon(pts[:, 1], pts[:, 0], shape)
        m[rr, cc] = True
    return m


def load_aul(root, size=64):
    """Returns list of dicts {id, cls, us (S,S) in [0,1], liver (S,S) bool}. Format verified on the real files."""
    from PIL import Image
    out = []
    for img_path in sorted(glob.glob(os.path.join(root, "**", "image", "*.*"), recursive=True)):
        cls_dir = img_path.split(os.sep)[-3]
        stem = os.path.splitext(os.path.basename(img_path))[0]
        im = np.asarray(Image.open(img_path).convert("L"), np.float32) / 255.0
        seg = None
        for cand in glob.glob(os.path.join(os.path.dirname(os.path.dirname(img_path)), "segmentation", "liver", stem + ".*")):
            if cand.endswith(".json"):
                seg = _aul_mask_from_json(json.load(open(cand)), im.shape)
            else:
                seg = np.asarray(Image.open(cand).convert("L")) > 127
        if seg is None or seg.sum() == 0:
            continue
        out.append(dict(id=f"{cls_dir}/{stem}", cls=cls_dir, us=rs(im, size), liver=rs(seg.astype(np.float32), size, 0) > 0.5))
    return out


# ----------------------------------------------------------------------------- mu-RegPro (paired MR-TRUS, 3D)
def load_muregpro(root, size=48, pad=128):
    """Returns list of dicts {case, patient, mr, us, mr_lab (L,S,S,S), us_lab, spacing}.

    mu-RegPro volumes are 0.8 mm isotropic with zero origins and different sizes (MR 128x128x120,
    TRUS 88x118x81). Following common practice for this challenge, both are centre-padded to pad^3, which is
    the initial (centre) alignment; no label is used to align them. They are then downsampled to size^3.
    Channel 0 of the labels is the prostate gland; channels 1.. are corresponding landmarks.
    Cases sharing an identical MR volume belong to the same patient (grouped for patient-level splits).
    """
    import hashlib
    import SimpleITK as sitk
    sitk.ProcessObject_SetGlobalWarningDisplay(False)
    def arr(p):
        return sitk.GetArrayFromImage(sitk.ReadImage(p)).astype(np.float32)
    def cpad(v):
        sp = v.shape[-3:]; out = np.zeros(v.shape[:-3] + (pad,) * 3, np.float32)
        sl_src, sl_dst = [], []
        for n in sp:
            if n <= pad:
                o = (pad - n) // 2; sl_dst.append(slice(o, o + n)); sl_src.append(slice(0, n))
            else:
                o = (n - pad) // 2; sl_dst.append(slice(0, pad)); sl_src.append(slice(o, o + pad))
        out[(Ellipsis,) + tuple(sl_dst)] = v[(Ellipsis,) + tuple(sl_src)]
        return out
    def r3(v, order):
        return resize(v, (size,) * 3, order=order, preserve_range=True, anti_aliasing=False).astype(np.float32)
    cases, groups = [], {}
    for mf in sorted(glob.glob(os.path.join(root, "**", "mr_images", "*.nii*"), recursive=True)):
        base = os.path.dirname(os.path.dirname(mf)); name = os.path.basename(mf)
        paths = [os.path.join(base, d, name) for d in ("us_images", "mr_labels", "us_labels")]
        if not all(os.path.exists(p) for p in paths):
            continue
        h = hashlib.md5(open(mf, "rb").read()).hexdigest()
        patient = groups.setdefault(h, f"patient{len(groups):03d}")
        mr, us = cpad(arr(mf)), cpad(arr(paths[0]))
        ml, ul = cpad(arr(paths[1])), cpad(arr(paths[2]))
        cases.append(dict(case=name.split(".")[0], patient=patient,
                          mr=norm01(r3(mr, 1)), us=norm01(r3(us, 1)),
                          mr_lab=np.stack([r3(c / 255.0, 1) for c in ml]) > 0.5,
                          us_lab=np.stack([r3(c / 255.0, 1) for c in ul]) > 0.5,
                          spacing=(0.8 * pad / size,) * 3))
    return cases


# ----------------------------------------------------------------------------- synthetic fixture (PLUMBING TEST ONLY)
def synthetic_fixture(n=24, size=64, dim=2, seed=0):
    """Ellipsoidal 'organ' phantoms with an MRI-like and a speckled US-like rendering. NOT experimental data."""
    rng = np.random.default_rng(seed)
    g = np.stack(np.meshgrid(*[np.linspace(-1, 1, size)] * dim, indexing="ij"))
    out = []
    for i in range(n):
        c = rng.uniform(-0.2, 0.2, dim); r = rng.uniform(0.3, 0.5, dim)
        organ = (((g - c.reshape((-1,) + (1,) * dim)) / r.reshape((-1,) + (1,) * dim)) ** 2).sum(0) < 1
        lm = (((g - c.reshape((-1,) + (1,) * dim)) / 0.08) ** 2).sum(0) < 1
        mri = 0.3 + 0.4 * organ + 0.05 * rng.standard_normal(organ.shape)
        shift = rng.integers(-3, 4, dim)
        organ_us = np.roll(organ, shift, axis=tuple(range(dim))); lm_us = np.roll(lm, shift, axis=tuple(range(dim)))
        us = 0.2 + 0.3 * organ_us * rng.rayleigh(0.6, organ.shape) + 0.1 * rng.rayleigh(0.5, organ.shape)
        out.append(dict(case=f"synthetic{i:03d}", mri=np.clip(mri, 0, 1).astype(np.float32), us=np.clip(us, 0, 1).astype(np.float32),
                        mri_lab=np.stack([organ, lm]), us_lab=np.stack([organ_us, lm_us]), spacing=(1.0,) * dim))
    return out
