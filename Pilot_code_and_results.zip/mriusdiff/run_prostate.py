"""Paired MRI-TRUS experiment (mu-RegPro): translation bridge + 3D registration, baselines and ablations.

python run_prostate.py --config configs/pilot.yaml --data /path/to/muregpro --out results/prostate
python run_prostate.py --config configs/fixture.yaml --fixture --out results/fixture_prostate   # plumbing test only
"""
import argparse, json, os, sys, time
import numpy as np, pandas as pd, yaml
sys.path.insert(0, os.path.dirname(__file__))
from mriusdiff.data import load_muregpro, synthetic_fixture
from mriusdiff.train import train_translator, train_registration
from mriusdiff.models import warp
from mriusdiff.losses_metrics import dice, hd95, asd, tre, folding_percent, inception_features, fid_from_feats, kid_from_feats
import torch

ap = argparse.ArgumentParser()
ap.add_argument("--config", required=True); ap.add_argument("--data"); ap.add_argument("--out", required=True)
ap.add_argument("--fixture", action="store_true"); ap.add_argument("--stop_after_translation", action="store_true")
a = ap.parse_args()
cfg = yaml.safe_load(open(a.config)); os.makedirs(a.out, exist_ok=True)
logf = open(os.path.join(a.out, "log.txt"), "a")
def log(s):
    print(s); logf.write(s + "\n"); logf.flush()
torch.set_num_threads(cfg.get("threads", 2))
S = cfg["size3d"]

# ------------------------------------------------------------------ data and split (patient level, seeded)
if a.fixture:
    raw = synthetic_fixture(cfg.get("fixture_n", 16), S, dim=3, seed=0)
    cases = [dict(case=r["case"], mr=r["mri"], us=r["us"], mr_lab=r["mri_lab"], us_lab=r["us_lab"], spacing=r["spacing"]) for r in raw]
    log("!!! SYNTHETIC FIXTURE: plumbing test only, not experimental data")
else:
    cases = load_muregpro(a.data, S)
    log(f"mu-RegPro: {len(cases)} MR-TRUS pairs from {len({c['patient'] for c in cases})} patients")
log(f"loaded {len(cases)} cases; label channels: {cases[0]['mr_lab'].shape[0]}")
rng = np.random.default_rng(cfg["split_seed"])
pats = sorted({c.get("patient", c["case"]) for c in cases}); pp = rng.permutation(pats)
test_p = set(pp[:max(1, int(round(cfg["test_frac"] * len(pats))))].tolist())       # patient-level split
test_idx = [i for i, c in enumerate(cases) if c.get("patient", c["case"]) in test_p]
train_idx = [i for i, c in enumerate(cases) if c.get("patient", c["case"]) not in test_p]
json.dump({"train": [cases[i]["case"] for i in train_idx], "test": [cases[i]["case"] for i in test_idx]},
          open(os.path.join(a.out, "split.json"), "w"), indent=1)
train_all, test = [cases[i] for i in train_idx], [cases[i] for i in test_idx]
tr_p = sorted({c.get("patient", c["case"]) for c in train_all}); vp = np.random.default_rng(cfg["split_seed"] + 1).permutation(tr_p)
val_p = set(vp[:max(1, int(round(cfg.get("val_frac", 0.15) * len(tr_p))))].tolist())
val = [c for c in train_all if c.get("patient", c["case"]) in val_p]
train = [c for c in train_all if c.get("patient", c["case"]) not in val_p]
json.dump({"train": [c["case"] for c in train], "val": [c["case"] for c in val], "test": [c["case"] for c in test]},
          open(os.path.join(a.out, "split.json"), "w"), indent=1)
log(f"validation (for smoothness-weight selection only): {len(val)} cases from {len(val_p)} patients; training: {len(train)} cases")
log(f"split: {len(train)} train / {len(test)} test cases from {len(pats) - len(test_p)} / {len(test_p)} patients")

# ------------------------------------------------------------------ Stage 1: slice-wise translators (paired slices)
def slices(cs, key):
    return np.concatenate([c[key] for c in cs])          # axial slices (axis 0)
keep = lambda cs: np.concatenate([(c["us"].reshape(S, -1).std(1) > 0.02) for c in cs])
m_tr, u_tr = slices(train, "mr"), slices(train, "us"); k = keep(train)
m_tr, u_tr = m_tr[k], u_tr[k]
log(f"translator training pairs (same-patient slices): {len(m_tr)}")
translators, cal = [], {}
for name, kind, enc in cfg["translators"]:
    cache = os.path.join(a.out, f"calibrated_{name}.npz")
    translators.append(name)
    if os.path.exists(cache):
        z = np.load(cache); cal[name] = {k: z[k] for k in z.files}; log(f"loaded cached calibrated volumes for {name}"); continue
    t0 = time.time(); wpath = os.path.join(a.out, f"translator_{name}.pt")
    g = train_translator(m_tr, u_tr, cfg, cfg["translator_seed"], kind, enc, log,
                         state=torch.load(wpath) if os.path.exists(wpath) else None)
    log(f"trained translator {name} in {time.time() - t0:.0f}s")
    t0 = time.time()
    cal[name] = {c["case"]: g(c["mr"], seed_g=0, volume=True) for c in train + val + test}   # slice-consistent volume
    np.savez_compressed(cache, **cal[name]); torch.save(g.net.state_dict(), os.path.join(a.out, f"translator_{name}.pt"))
    log(f"generated calibrated volumes for {name} in {time.time() - t0:.0f}s")

if a.stop_after_translation:
    log("stopping after translation stage (calibrated volumes cached)"); sys.exit(0)
# translation realism on test patients (distribution level; slices of same patients but not voxel-aligned)
rows = []
real_feats = inception_features(slices(test, "us")[keep(test)])
for name in translators:
    fake = np.concatenate([cal[name][c["case"]] for c in test])[keep(test)]
    ff = inception_features(fake)
    kid_m, kid_s = kid_from_feats(ff, real_feats)
    rows.append(dict(method=name, fid=fid_from_feats(ff, real_feats), kid=kid_m, kid_sd=kid_s, n_fake=len(fake), n_real=len(real_feats)))
pd.DataFrame(rows).to_csv(os.path.join(a.out, "translation_realism.csv"), index=False)
log(str(pd.DataFrame(rows)))

# ------------------------------------------------------------------ Stage 2: registration methods x seeds
def evaluate(c, flow, method, seed, rec_lm):
    sp = c["spacing"]
    wl = warp(torch.from_numpy(c["us_lab"].astype(np.float32))[None], torch.from_numpy(flow)[None])[0].numpy() > 0.5
    g_mr, g_us = c["mr_lab"][0], wl[0]
    lms = []
    for j in range(1, c["mr_lab"].shape[0]):
        if c["mr_lab"][j].any() and c["us_lab"][j].any():
            e = tre(c["mr_lab"][j], wl[j], sp); lms.append(e)
            rec_lm.append(dict(patient_id=c["case"], landmark_id=j, method=method, seed=seed, tre_mm=e))
    return dict(case_id=c["case"], method=method, seed=seed, dice=dice(g_mr, g_us), hd95_mm=hd95(g_mr, g_us, sp),
                asd_mm=asd(g_mr, g_us, sp), tre_mm=float(np.nanmean(lms)) if lms else np.nan,
                n_landmarks=len(lms), nonpos_jacobian_pct=folding_percent(flow))

per_case, per_lm, qual = [], [], {}
for c in test:
    zero = np.zeros((3,) + c["mr"].shape, np.float32)
    per_case.append(evaluate(c, zero, "Before registration", 0, per_lm))

mov_tr = np.stack([c["us"] for c in train]); mri_tr = np.stack([c["mr"] for c in train])
chosen = []
for meth in cfg["reg_methods"]:
    name, bridge, loss_kind, aw = meth["name"], meth.get("bridge"), meth["loss"], meth.get("anatomy", True)
    fixed_tr = mri_tr if bridge is None else np.stack([cal[bridge][c["case"]] for c in train])
    fx_of = lambda c: c["mr"] if bridge is None else cal[bridge][c["case"]]
    # smoothness weight chosen on the validation patients only (gland Dice), seed 0
    best, models = None, {}
    for lam in cfg["lambda_grid"]:
        t0 = time.time()
        reg = train_registration(mov_tr, fixed_tr, mri_tr, cfg, 0, loss_kind, aw, log, lambda_smooth=lam)
        vd = float(np.nanmean([evaluate(c, reg(c["us"], fx_of(c)), name, 0, [])["dice"] for c in val]))
        log(f"  {name}: lambda={lam} validation gland Dice {vd:.3f} ({time.time() - t0:.0f}s)")
        chosen.append(dict(method=name, lambda_smooth=lam, val_dice=vd)); models[lam] = reg
        if best is None or vd > best[1] + 1e-9:
            best = (lam, vd)
    lam = best[0]; log(f"selected lambda={lam} for {name}")
    pd.DataFrame(chosen).to_csv(os.path.join(a.out, "lambda_selection.csv"), index=False)
    for seed in cfg["reg_seeds"]:
        t0 = time.time()
        reg = models[lam] if seed == 0 else train_registration(mov_tr, fixed_tr, mri_tr, cfg, seed, loss_kind, aw, log, lambda_smooth=lam)
        log(f"trained {name} seed {seed} in {time.time() - t0:.0f}s")
        for c in test:
            t1 = time.time(); flow = reg(c["us"], fx_of(c)); dt = time.time() - t1
            rr = evaluate(c, flow, name, seed, per_lm); rr["reg_time_s"] = dt; rr["lambda_smooth"] = lam; per_case.append(rr)
            if seed == cfg["reg_seeds"][0]:
                qual.setdefault(c["case"], {})[name] = flow
        pd.DataFrame(per_case).to_csv(os.path.join(a.out, "per_case_paired_all_seeds.csv"), index=False)

pc = pd.DataFrame(per_case); lm = pd.DataFrame(per_lm)
pc.to_csv(os.path.join(a.out, "per_case_paired_all_seeds.csv"), index=False)
lm.to_csv(os.path.join(a.out, "per_landmark_tre_all_seeds.csv"), index=False)
# seed-averaged per-case values (the unit for statistics is the patient)
pc.groupby(["case_id", "method"], as_index=False).mean(numeric_only=True).drop(columns="seed").to_csv(
    os.path.join(a.out, "per_case_paired.csv"), index=False)
lm.groupby(["patient_id", "landmark_id", "method"], as_index=False)["tre_mm"].mean().to_csv(
    os.path.join(a.out, "per_landmark_tre.csv"), index=False)
# qualitative arrays for make_qualitative_figures.py (first test patient, mid-gland slice)
c = test[0]; z = int(np.argmax(c["mr_lab"][0].sum((1, 2))))
qd = os.path.join(a.out, "qualitative", c["case"]); os.makedirs(qd, exist_ok=True)
np.save(os.path.join(qd, "mri.npy"), c["mr"][z]); np.save(os.path.join(qd, "trus.npy"), c["us"][z])
np.save(os.path.join(qd, "mri_mask.npy"), c["mr_lab"][0][z])
for name, flow in qual[c["case"]].items():
    w_us = warp(torch.from_numpy(c["us"])[None, None], torch.from_numpy(flow)[None])[0, 0].numpy()
    w_lab = warp(torch.from_numpy(c["us_lab"][:1].astype(np.float32))[None], torch.from_numpy(flow)[None])[0, 0].numpy() > 0.5
    tag = name.lower().replace(" ", "_").replace("(", "").replace(")", "").replace("/", "")
    np.save(os.path.join(qd, f"{tag}.npy"), w_us[z]); np.save(os.path.join(qd, f"mask_{tag}.npy"), w_lab[z])
    np.save(os.path.join(qd, f"flow_{tag}.npy"), flow[:, z])
for name in translators:
    np.save(os.path.join(qd, f"calibrated_{name}.npy"), cal[name][c["case"]][z])
json.dump(cfg, open(os.path.join(a.out, "config_used.json"), "w"), indent=1)
log("done")
