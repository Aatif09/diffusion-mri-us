"""Unpaired liver experiment: CHAOS MR -> AUL-style ultrasound translation, anatomical consistency,
distribution-level realism (FID/KID) and downstream ultrasound liver segmentation.

python run_liver.py --config configs/pilot.yaml --chaos /path/CHAOS_MR --aul /path/AUL --out results/liver
python run_liver.py --config configs/fixture.yaml --fixture --out /tmp/fixture_liver     # plumbing test only
"""
import argparse, json, os, sys, time
import numpy as np, pandas as pd, yaml, torch
sys.path.insert(0, os.path.dirname(__file__))
from mriusdiff.data import load_chaos_mr, load_aul, synthetic_fixture
from mriusdiff.train import train_translator, train_segmenter
from mriusdiff.losses_metrics import dice, hd95, inception_features, fid_from_feats, kid_from_feats

ap = argparse.ArgumentParser()
ap.add_argument("--config", required=True); ap.add_argument("--chaos"); ap.add_argument("--aul")
ap.add_argument("--out", required=True); ap.add_argument("--fixture", action="store_true")
a = ap.parse_args()
cfg = yaml.safe_load(open(a.config)); os.makedirs(a.out, exist_ok=True)
logf = open(os.path.join(a.out, "log.txt"), "a")
def log(s):
    print(s); logf.write(s + "\n"); logf.flush()
torch.set_num_threads(cfg.get("threads", 2)); S = cfg["size2d"]

# ------------------------------------------------------------------ data
if a.fixture:
    log("!!! SYNTHETIC FIXTURE: plumbing test only, not experimental data")
    fx = synthetic_fixture(120, S, 2, 0)
    chaos = [dict(subject=f"s{i // 10}", slice=i, mri=f["mri"], liver=f["mri_lab"][0]) for i, f in enumerate(fx[:60])]
    aul = [dict(id=f"img{i}", cls="Normal", us=f["us"], liver=f["us_lab"][0]) for i, f in enumerate(fx[60:])]
else:
    chaos = load_chaos_mr(a.chaos, S); aul = load_aul(a.aul, S)
subjects = sorted({c["subject"] for c in chaos})
log(f"CHAOS: {len(chaos)} liver slices from {len(subjects)} subjects; AUL: {len(aul)} images")
rng = np.random.default_rng(cfg["split_seed"])
perm = rng.permutation(subjects); n_te = max(1, int(round(cfg["test_frac"] * len(subjects))))
chaos_te_subj = set(perm[:n_te].tolist())
c_tr = [c for c in chaos if c["subject"] not in chaos_te_subj]; c_te = [c for c in chaos if c["subject"] in chaos_te_subj]
# AUL: image-level split stratified by class (no patient identifiers are distributed with AUL)
aul_tr, aul_te = [], []
for cls in sorted({x["cls"] for x in aul}):
    xs = [x for x in aul if x["cls"] == cls]; p = rng.permutation(len(xs)); k = int(round(cfg["test_frac"] * len(xs)))
    aul_te += [xs[i] for i in p[:k]]; aul_tr += [xs[i] for i in p[k:]]
json.dump({"chaos_test_subjects": sorted(chaos_te_subj), "aul_test": [x["id"] for x in aul_te]},
          open(os.path.join(a.out, "split.json"), "w"), indent=1)
log(f"split: CHAOS {len(c_tr)}/{len(c_te)} slices; AUL {len(aul_tr)}/{len(aul_te)} images")
M_tr = np.stack([c["mri"] for c in c_tr]); L_tr = np.stack([c["liver"] for c in c_tr])
M_te = np.stack([c["mri"] for c in c_te]); L_te = np.stack([c["liver"] for c in c_te])
U_tr = np.stack([x["us"] for x in aul_tr]); UL_tr = np.stack([x["liver"] for x in aul_tr])
U_te = np.stack([x["us"] for x in aul_te]); UL_te = np.stack([x["liver"] for x in aul_te])

# ------------------------------------------------------------------ translators on random cross-subject tuples
tup = rng.integers(0, len(U_tr), size=len(M_tr))          # the tuple-formation rule used for every paired-input model
json.dump({"rule": "each CHAOS training slice paired with a uniformly random AUL training image", "seed": cfg["split_seed"]},
          open(os.path.join(a.out, "tuple_rule.json"), "w"))
gens = {}
for name, kind, enc in cfg["liver_translators"]:
    t0 = time.time(); gens[name] = train_translator(M_tr, U_tr[tup], cfg, cfg["translator_seed"], kind, enc, log)
    log(f"trained {name} in {time.time() - t0:.0f}s")

# ------------------------------------------------------------------ US liver segmenter (trained on real AUL only) for anatomical consistency
seg_us = train_segmenter(U_tr, UL_tr, cfg, 0, log)
seg_real_dice = [dice(p, g) for p, g in zip(seg_us(U_te), UL_te)]
log(f"AUL-trained segmenter on real AUL test: Dice {np.nanmean(seg_real_dice):.3f} ± {np.nanstd(seg_real_dice):.3f}")

real_f = inception_features(U_te)
trans_rows, real_rows, syn_te = [], [], {}
for name, g in gens.items():
    syn = g(M_te, seed_g=0); syn_te[name] = syn
    ff = inception_features(syn); km, ks = kid_from_feats(ff, real_f)
    real_rows.append(dict(method=name, fid=fid_from_feats(ff, real_f), kid=km, kid_sd=ks, n_fake=len(syn), n_real=len(U_te)))
    pred = seg_us(syn)
    for c, p, gmask in zip(c_te, pred, L_te):
        trans_rows.append(dict(case_id=f"{c['subject']}_{c['seq']}_{c['slice']}", subject=c["subject"], method=name,
                               anat_dice=dice(p, gmask), anat_hd95_mm=hd95(p, gmask, (1.0, 1.0))))
pd.DataFrame(real_rows).to_csv(os.path.join(a.out, "translation_realism.csv"), index=False)
pd.DataFrame(trans_rows).to_csv(os.path.join(a.out, "per_case_translation.csv"), index=False)
log(str(pd.DataFrame(real_rows)))
log(str(pd.DataFrame(trans_rows).groupby("method")[["anat_dice", "anat_hd95_mm"]].agg(["mean", "std"])))

# ------------------------------------------------------------------ downstream segmentation on real AUL test images
syn_tr = {name: gens[name](M_tr, seed_g=1) for name in cfg["augment_with"].values()}
configs = {"MRI only": (M_tr, L_tr), "MRI + real US": (np.concatenate([M_tr, U_tr]), np.concatenate([L_tr, UL_tr]))}
for label, name in cfg["augment_with"].items():
    configs[label] = (np.concatenate([M_tr, syn_tr[name]]), np.concatenate([L_tr, L_tr]))   # labels = source MRI masks
seg_rows = []
for label, (X, Y) in configs.items():
    for seed in cfg["seg_seeds"]:
        pr = train_segmenter(X, Y, cfg, seed, log)(U_te)
        for x, p, gm in zip(aul_te, pr, UL_te):
            seg_rows.append(dict(case_id=x["id"], method=label, seed=seed, n_train=len(X), dice=dice(p, gm)))
sr = pd.DataFrame(seg_rows); sr.to_csv(os.path.join(a.out, "per_case_segmentation_all_seeds.csv"), index=False)
sr.groupby(["case_id", "method"], as_index=False).mean(numeric_only=True).drop(columns="seed").to_csv(
    os.path.join(a.out, "per_case_segmentation.csv"), index=False)
log(str(sr.groupby("method")["dice"].agg(["mean", "std", "count"])))

# qualitative arrays (first test subject, slice with the largest liver) for make_qualitative_figures.py --task liver
i = int(np.argmax(L_te.reshape(len(L_te), -1).sum(1)))
qd = os.path.join(a.out, "qualitative", f"{c_te[i]['subject']}_{c_te[i]['slice']}"); os.makedirs(qd, exist_ok=True)
np.save(os.path.join(qd, "mri.npy"), M_te[i]); np.save(os.path.join(qd, "mri_liver_mask.npy"), L_te[i])
np.save(os.path.join(qd, "aul_reference.npy"), U_te[0])
for name, syn in syn_te.items():
    np.save(os.path.join(qd, f"{name}.npy"), syn[i])
json.dump(cfg, open(os.path.join(a.out, "config_used.json"), "w"), indent=1)
log("done")
