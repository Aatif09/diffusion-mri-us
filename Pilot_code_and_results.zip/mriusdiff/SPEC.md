# Implementation specification (from the revised manuscript, round 3)

## Task
1. **Translation:** synthesise an MRI-calibrated ultrasound image Î_US from an MRI slice (2D) with a
   ViT-conditioned diffusion model.
2. **Registration:** estimate a deformation φ = R_ω(I_US, Î_US). The real ultrasound is the moving image
   and the calibrated US is the fixed image. φ warps the real US into the MRI frame.

## Components (each can be switched off in the config, for ablation)
| ID | Component | Config switch | Ablation replacement |
|----|-----------|---------------|----------------------|
| C1 | ViT encoder for MRI conditioning (cross-attention at every U-Net scale) | `translator.encoder: vit` | `cnn` (small CNN encoder that produces the same token shape) |
| C2 | Diffusion translation (cosine schedule, ε-prediction, DDIM sampling) | `translator.kind: diffusion` | `pix2pix` (conditional GAN generator as the bridge) |
| C3 | Calibrated image as the fixed image of the registration (bridge) | `registration.fixed: calibrated` | `mri` + cross-modal MIND loss, which is the VoxelMorph baseline |
| C4 | Anatomy-aware weighting w(x) = σ(κ(τ − I_MRI(x))) | `registration.anatomy_weight: true` | uniform weights |
| C5 | Smoothness penalty ‖∇φ‖² | `registration.lambda_smooth` | (always on) |

## Baselines
- Translation: CNN encoder–decoder (L1), pix2pix (on the same tuples), CycleGAN (unpaired).
- Registration: identity (before registration); VoxelMorph-style network with the MRI as fixed image and
  MIND-SSC dissimilarity. The cross-modal attention network [3] and DiffuseMorph [17] are **not
  reimplemented** in the pilot.

## Metrics
- Translation (unpaired liver): FID, KID (Inception-v3, pytorch-fid weights) against held-out real AUL
  images; anatomical consistency, meaning the Dice/HD95 between the liver mask predicted on the synthetic US
  by an AUL-trained U-Net and the CHAOS mask of the conditioning MRI.
- Registration (paired μ-RegPro, 3D): gland Dice, HD95, ASD; landmark TRE (centroids of the corresponding
  landmark labels); folding (% of voxels with det J ≤ 0).
- Downstream segmentation: Dice of a U-Net segmenting the liver in AUL test images, under 4 training-data
  configurations.
- Statistics: mean ± SD over test cases; two-sided Wilcoxon signed-rank tests with Holm correction;
  3 seeds where time allows.

## Issues in the description and how they are resolved here
1. **Unpaired training tuples (liver).** CHAOS and AUL come from different subjects, so the conditional
   diffusion is trained on random cross-subject tuples, as the manuscript describes. Whether the output
   follows the MRI anatomy is measured, not assumed (anatomical consistency).
2. **Joint vs two-stage training.** Algorithm 2 trains both stages jointly through a one-step estimate.
   The pilot trains them **sequentially** (diffusion first, then registration on DDIM-sampled calibrated
   images), which is cheaper on CPU and makes the bridge image identical at training and test time.
   This is a stated deviation.
3. **Latent vs pixel diffusion.** The pilot uses **pixel-space** diffusion at low resolution, with no
   autoencoder (a stated deviation). `translator.latent` is a placeholder for the full-scale run.
4. **3D vs 2D.** μ-RegPro registration is 3D (volumes resampled to a coarse grid). Translation is 2D,
   slice by slice; the slices are stacked into a calibrated volume.
5. **Labels at test time.** No labels are used at inference. Labels and landmarks are used only for
   evaluation.

## Hyperparameters chosen by this implementation (not stated in the manuscript)
Image size, ViT depth/width, U-Net widths, training steps, κ, τ, λ_smooth, NCC window and MIND radius are
all recorded in `configs/*.yaml` and copied into every result file.
