"""Figures 10 and 11 from the saved mu-RegPro pilot outputs (real test patient)."""
import os, sys, glob, json
import numpy as np, torch, yaml
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
sys.path.insert(0, os.path.dirname(__file__))
from mriusdiff.models import Translator
from mriusdiff.losses_metrics import folding_percent

RES, OUT = sys.argv[1], sys.argv[2]
qd = sorted(glob.glob(os.path.join(RES, "qualitative", "*")))[0]; case = os.path.basename(qd)
L = lambda n: np.load(os.path.join(qd, n + ".npy"))
GREEN, BLUE, VERM, SKY = "#009E73", "#0072B2", "#D55E00", "#56B4E9"

def lab(ax, s):
    ax.text(0.03, 0.97, s, transform=ax.transAxes, ha="left", va="top", fontsize=5, color="white", weight="bold",
            bbox=dict(fc="black", ec="none", alpha=0.55, pad=1.2))

# Figure 10: registration of one paired test patient
panels = [("mri", "(a) MRI"), ("trus", "(b) TRUS (initial)"), ("calibrated_diffusion_vit", "(c) Calibrated US"),
          ("voxelmorph_mind", "(d) VoxelMorph"), ("proposed", "(e) Proposed"), ("mri", "(f) Contours")]
fig, axs = plt.subplots(1, 6, figsize=(7.2, 1.45))
for ax, (k, s) in zip(axs, panels):
    ax.imshow(L(k), cmap="gray", vmin=0, vmax=1); ax.axis("off"); lab(ax, s)
mri_mask = L("mri_mask")
axs[5].contour(mri_mask, [0.5], colors=[GREEN], linewidths=1.1)
from mriusdiff.data import load_muregpro  # noqa
axs[5].contour(np.load(os.path.join(qd, "mask_voxelmorph_mind.npy")), [0.5], colors=[BLUE], linewidths=0.9, linestyles="--")
axs[5].contour(np.load(os.path.join(qd, "mask_proposed.npy")), [0.5], colors=[VERM], linewidths=0.9)
fig.tight_layout(pad=0.2); fig.savefig(os.path.join(OUT, "fig10_prostate_registration.png"), dpi=600, bbox_inches="tight", facecolor="white")
plt.close(fig)

# Figure 11: ViT attention rollout over the MRI slice + Jacobian determinant of the proposed deformation
cfg = json.load(open(os.path.join(RES, "config_used.json"))); tc = cfg["translator"]; S = cfg["size3d"]
net = Translator(S, "vit", "diffusion", tc["dim"], tc["depth"], tc["patch"], tuple(tc["ch"]))
net.load_state_dict(torch.load(os.path.join(RES, "translator_diffusion_vit.pt"))); net.eval()
vit = net.enc; x = torch.from_numpy(L("mri"))[None, None].float()
with torch.no_grad():
    t = vit.proj(x).flatten(2).transpose(1, 2) + vit.pos
    roll = torch.eye(t.shape[1])
    for layer in vit.enc.layers:
        h = layer.norm1(t)
        _, w = layer.self_attn(h, h, h, need_weights=True, average_attn_weights=True)
        a = 0.5 * w[0] + 0.5 * torch.eye(w.shape[-1]); a = a / a.sum(-1, keepdim=True)
        roll = a @ roll
        t = t + layer.self_attn(h, h, h, need_weights=False)[0]; t = t + layer._ff_block(layer.norm2(t))
    g = S // tc["patch"]; att = roll.mean(0).reshape(g, g).numpy()
att = np.kron(att, np.ones((tc["patch"], tc["patch"]))); att = (att - att.min()) / (np.ptp(att) + 1e-8)
flow = L("flow_proposed")                        # (3, S, S) at the displayed axial slice: (dz, dy, dx)
u = flow[1:]                                     # in-plane components
J = (1 + np.gradient(u[0], axis=0)) * (1 + np.gradient(u[1], axis=1)) - np.gradient(u[0], axis=1) * np.gradient(u[1], axis=0)
fig, axs = plt.subplots(1, 2, figsize=(4.6, 2.1))
axs[0].imshow(L("mri"), cmap="gray"); axs[0].imshow(att, cmap="magma", alpha=0.45); axs[0].axis("off"); lab(axs[0], "(a) ViT attention rollout")
lim = max(abs(J.min() - 1), abs(J.max() - 1), 0.05)
im = axs[1].imshow(J, cmap="RdBu_r", norm=TwoSlopeNorm(vcenter=1.0, vmin=1 - lim, vmax=1 + lim)); axs[1].axis("off"); lab(axs[1], "(b) In-plane Jacobian det.")
if (J <= 0).any():
    axs[1].contour(J <= 0, [0.5], colors=["black"], linewidths=0.7)
cb = fig.colorbar(im, ax=axs[1], fraction=0.046, pad=0.02); cb.ax.tick_params(labelsize=6)
fig.tight_layout(pad=0.2); fig.savefig(os.path.join(OUT, "fig11_attention_jacobian.png"), dpi=600, bbox_inches="tight", facecolor="white")
print("case", case, "| in-plane J range %.3f..%.3f" % (J.min(), J.max()))
