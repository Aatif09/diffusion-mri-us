# CPU pilot results: ViT-conditioned diffusion bridge for MRI–ultrasound registration

All numbers below come from code that ran in this workspace. The tables are generated from the result files in
`results/` by `analyse.py`. The pilot runs at **reduced scale on CPU** (2 cores, no GPU), so it is a feasibility
test of the method as described. It does not replicate the manuscript's full-scale setting.

## 1. What ran
| Item | Setting |
|---|---|
| Hardware | 2 CPU cores, 7 GB RAM, no GPU; PyTorch 2.14 (CPU) |
| Paired prostate data | μ-RegPro training release: 65 MRI–TRUS pairs from 46 patients. Patient-level split: 37 patients for training (45 pairs, of which 6 patients / 7 pairs held out for validation) and 9 test patients (13 pairs, 45 landmark pairs). Volumes centre-padded to 128³ at 0.8 mm, then resampled to 48³ (2.13 mm). |
| Liver data | CHAOS MR, 10 of the 20 annotated subjects recovered from the upload: 392 liver slices (T2-SPIR and T1 in-phase); subject-level split 7/3. AUL: 732 images with liver outlines; class-stratified, image-level split 512/220 (AUL has no patient IDs). Images at 64×64. |
| Translators | ViT (dim 128, depth 4, 8×8 patches) with a cross-attention U-Net, pixel-space diffusion (T = 1000, cosine schedule, ε-prediction), 25 DDIM steps. Equal step budgets for every translator: 6,000 steps (prostate) and 2,000 steps (liver), batch 16, AdamW. |
| Registration | VoxelMorph-style 3D U-Net with a diffeomorphic field (scaling and squaring), 800 steps. Smoothness weight chosen per method **on validation patients only** from {1, 4, 16}; 3 seeds per method. |
| Statistics | Mean ± SD over test units; two-sided Wilcoxon signed-rank tests against the proposed method, Holm-corrected. Prostate statistics are computed at patient level (pairs of the same patient averaged). |

## 2. Paired MRI–TRUS registration (μ-RegPro test set)
| Method                     |   n patients | Gland Dice   | HD95 (mm)   | ASD (mm)    | TRE (mm)     | Folding (%)   | p Dice (Holm)   | p TRE (Holm)   |
|:---------------------------|-------------:|:-------------|:------------|:------------|:-------------|:--------------|:----------------|:---------------|
| Before registration        |            9 | 0.66 ± 0.11  | 9.8 ± 2.2   | 4.73 ± 1.35 | 10.22 ± 2.19 | 0.00 ± 0.00   | 0.156           | 0.902          |
| Proposed                   |            9 | 0.62 ± 0.11  | 14.5 ± 3.3  | 5.83 ± 1.38 | 10.91 ± 2.40 | 0.00 ± 0.00   | –               | –              |
| VoxelMorph (MIND)          |            9 | 0.65 ± 0.11  | 10.7 ± 2.2  | 4.99 ± 1.34 | 10.68 ± 2.37 | 0.00 ± 0.00   | 0.195           | 1              |
| w/o ViT                    |            9 | 0.56 ± 0.15  | 12.9 ± 4.3  | 6.34 ± 2.27 | 13.29 ± 4.04 | 0.00 ± 0.00   | 0.25            | 0.297          |
| w/o anatomy-aware loss     |            9 | 0.66 ± 0.11  | 10.0 ± 2.5  | 4.77 ± 1.32 | 10.15 ± 2.34 | 0.00 ± 0.00   | 0.137           | 0.195          |
| w/o diffusion (GAN bridge) |            9 | 0.66 ± 0.10  | 9.7 ± 2.3   | 4.64 ± 1.29 | 10.16 ± 2.21 | 0.00 ± 0.00   | 0.164           | 0.902          |

*Validation-selected smoothness weights:*
| method                     |   lambda_smooth |   val_dice |
|:---------------------------|----------------:|-----------:|
| VoxelMorph (MIND)          |               1 |      0.64  |
| VoxelMorph (MIND)          |               4 |      0.674 |
| VoxelMorph (MIND)          |              16 |      0.66  |
| Proposed                   |               1 |      0     |
| Proposed                   |               4 |      0.65  |
| Proposed                   |              16 |      0.583 |
| w/o anatomy-aware loss     |               1 |      0.096 |
| w/o anatomy-aware loss     |               4 |      0.646 |
| w/o anatomy-aware loss     |              16 |      0.659 |
| w/o ViT                    |               1 |      0.595 |
| w/o ViT                    |               4 |      0.675 |
| w/o ViT                    |              16 |      0.678 |
| w/o diffusion (GAN bridge) |               1 |      0.655 |
| w/o diffusion (GAN bridge) |               4 |      0.65  |
| w/o diffusion (GAN bridge) |              16 |      0.66  |

*Seed variability (SD of the test-set mean across 3 seeds):*
| method                     |    dice |   tre_mm |
|:---------------------------|--------:|---------:|
| Before registration        | nan     |  nan     |
| Proposed                   |   0.01  |    0.625 |
| VoxelMorph (MIND)          |   0.005 |    0.165 |
| w/o ViT                    |   0.081 |    2.524 |
| w/o anatomy-aware loss     |   0.008 |    0.288 |
| w/o diffusion (GAN bridge) |   0.004 |    0.193 |

**Finding.** No method improved on the initial centre alignment (TRE 10.22 ± 2.19 mm). The proposed bridge registration
did not improve on it either: TRE 10.91 ± 2.40 mm, gland Dice 0.62 vs 0.66 before registration. None of the differences
to the proposed method is significant after Holm correction (n = 9 patients, so statistical power is low). All
diffeomorphic fields were fold-free. Two earlier configurations that diverged (fixed λ = 0.2, and a 1,500-step
translator budget) are kept in `results/prostate_attempt*` and are not used.

*Translation realism on the prostate test slices (FID/KID against real TRUS slices):*
| method        |     fid |   kid |   n_fake |   n_real |
|:--------------|--------:|------:|---------:|---------:|
| diffusion_vit | 158.023 | 0.161 |      432 |      432 |
| diffusion_cnn | 183.425 | 0.211 |      432 |      432 |
| pix2pix       |  54.492 | 0.034 |      432 |      432 |

## 3. Liver translation (CHAOS MRI → AUL-style ultrasound, unpaired)
*Distribution-level realism against 220 held-out real AUL images:*
| method          |     fid |   kid |   n_fake |   n_real |
|:----------------|--------:|------:|---------:|---------:|
| proposed        | 266.624 | 0.312 |      114 |      220 |
| diffusion_noViT | 198.278 | 0.191 |      114 |      220 |
| pix2pix         | 161.151 | 0.137 |      114 |      220 |
| cnn_encdec      | 186.127 | 0.182 |      114 |      220 |
| cyclegan        | 132.669 | 0.077 |      114 |      220 |

*Anatomical consistency.* A U-Net trained on real AUL images (Dice 0.86 ± 0.11 on real AUL test images) segments the liver
on each synthetic image, and the result is compared with the expert CHAOS mask of the conditioning MRI slice. The
114 slices come from 3 subjects, so the slices are not independent and the p-values are optimistic.
| Method          |   n slices | Anatomical Dice   | Anatomical HD95 (px, 64×64)   | p Dice (Holm)   |
|:----------------|-----------:|:------------------|:------------------------------|:----------------|
| proposed        |        114 | 0.20 ± 0.13       | 31.4 ± 7.7                    | –               |
| diffusion_noViT |        114 | 0.21 ± 0.14       | 30.4 ± 7.9                    | 0.0137          |
| pix2pix         |        114 | 0.26 ± 0.18       | 23.6 ± 8.1                    | 2.01e-07        |
| cnn_encdec      |        114 | 0.27 ± 0.17       | 24.3 ± 8.3                    | 8.41e-10        |
| cyclegan        |        114 | 0.29 ± 0.18       | 23.4 ± 8.0                    | 2.98e-14        |

## 4. Downstream liver segmentation (U-Net, evaluated on 220 real AUL test images, 3 seeds)
| Training data               |   Training images |   n test images | Dice on real AUL test   | p vs proposed (Holm)   |
|:----------------------------|------------------:|----------------:|:------------------------|:-----------------------|
| MRI + GAN-generated US      |               556 |             220 | 0.19 ± 0.12             | 3.4e-21                |
| MRI + proposed synthetic US |               556 |             220 | 0.35 ± 0.22             | –                      |
| MRI + real US               |               790 |             220 | 0.87 ± 0.09             | 2.27e-37               |
| MRI only                    |               278 |             220 | 0.33 ± 0.20             | 0.247                  |

## 5. What this means for the manuscript
1. **The pilot does not reproduce the manuscript's headline results.** At this scale the proposed diffusion translator
   had the worst FID on both organs and the lowest anatomical consistency on the liver, and the bridge did not improve
   registration on paired data.
2. **The MRI conditioning is barely used.** On validation patients the synthetic volumes change very little from slice to
   slice (across-slice SD 0.013–0.022 vs within-slice SD 0.32). Figure 9 shows the same behaviour on the liver: an
   ultrasound-like texture that does not follow the MRI liver outline. This supports Reviewer 4's concern directly.
3. **The manuscript's claim that synthetic augmentation beats real ultrasound is contradicted.** Real ultrasound
   augmentation gave Dice 0.87; the proposed synthetic augmentation gave 0.35, which is not significantly different from
   MRI-only training (0.33).
4. **These are reduced-scale results.** They do not prove that a full-scale model (ViT-B/16, latent diffusion,
   100k steps, 256² / 128³) would fail, but they give no support for the current claims. Any full-scale rerun should use
   the same protocol, splits and statistics (`configs/fullscale_gpu.yaml`).

## 6. Deviations from the manuscript and implementation choices
- Two-stage sequential training instead of joint training; pixel-space instead of latent diffusion; slice-wise 2D
  translation stacked into 3D with one shared noise image per volume (independent noise produced incoherent volumes).
- Registration: fixed image = calibrated US, moving image = real US, locally-normalised cross-correlation weighted by
  w(x) = σ(10(0.5 − I_MRI)) and restricted to the ultrasound field of view; diffeomorphic integration for all methods.
- VoxelMorph baseline: the same network with the MRI as fixed image and a MIND-SSC loss. **Cross-modal attention and
  DiffuseMorph were not reimplemented** and have no numbers here.
- No PROSTATEx–OpenPros (unpaired prostate) experiment was run: PROSTATEx MRI was not provided, and the OpenPros files
  received are tissue-label maps only.
- CHAOS: only 10 of 20 annotated subjects were available (the final archive part was missing). AUL split at image level.
- Liver HD95 is in pixels on the 64×64 grid, not millimetres.
