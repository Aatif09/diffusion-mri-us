# mriusdiff: ViT-conditioned diffusion bridge for MRI–ultrasound registration

This is a runnable implementation of the method in the revised manuscript. It covers translation, the
single anatomy-aware registration, the baselines, the ablations and the correspondence-aware evaluation.
`SPEC.md` lists each component, the ablation switches and every deviation from the manuscript.

## Experiments
| Script | Data | Writes |
|---|---|---|
| `run_prostate.py` | μ-RegPro (paired MRI–TRUS) | `per_case_paired.csv`, `per_landmark_tre.csv`, `translation_realism.csv`, `qualitative/` |
| `run_liver.py` | CHAOS MR + AUL (unpaired) | `per_case_translation.csv` (anatomical consistency), `translation_realism.csv` (FID/KID), `per_case_segmentation.csv`, `qualitative/` |

The CSV files feed `make_stats_and_tre_figure.py` and `make_qualitative_figures.py` in the revision toolkit.
Those scripts produce mean ± SD, n, Holm-adjusted Wilcoxon p-values, and Figures 7 and 9–11.

```bash
pip install torch torchvision pytorch-fid nibabel pydicom SimpleITK scikit-image scipy pandas pyyaml
# CPU pilot (reduced scale)
python run_prostate.py --config configs/pilot.yaml --data data/muregpro --out results/prostate
python run_liver.py    --config configs/pilot.yaml --chaos data/CHAOS_MR --aul data/AUL --out results/liver
# full scale on a GPU (MRIUS_DEVICE=cuda is picked up automatically when CUDA is available)
python run_prostate.py --config configs/fullscale_gpu.yaml --data data/muregpro --out results_gpu/prostate
```

`--fixture` runs either script on a synthetic phantom, as a **plumbing test only**. Never report those numbers.

## Not reimplemented
The cross-modal attention registration network and DiffuseMorph are not reimplemented here. If the
manuscript keeps them as baselines, they must be rerun with their published code on the same splits.
