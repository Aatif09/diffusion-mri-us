#!/bin/bash
# waits for the prostate translation stage, then runs the full prostate experiment, then the liver experiment
while kill -0 7833 2>/dev/null; do sleep 30; done
python3 -u run_prostate.py --config configs/pilot.yaml --data /home/claude/data_raw/muregpro --out results/prostate > results/prostate/stdout.txt 2>&1
mkdir -p results/liver
python3 -u run_liver.py --config configs/pilot_liver.yaml --chaos /home/claude/data_raw/chaos/CHAOS_Train_Sets --aul /home/claude/data_raw/aul --out results/liver > results/liver/stdout.txt 2>&1
